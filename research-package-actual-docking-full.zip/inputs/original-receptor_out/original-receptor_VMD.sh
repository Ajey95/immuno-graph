#!/bin/bash
vmd original-receptor_out.pdb -e original-receptor.tcl
