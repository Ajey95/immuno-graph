#!/bin/bash
pymol original-receptor.pml
